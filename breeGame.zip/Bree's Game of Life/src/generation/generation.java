package generation;
import java.util.Random;
public class generation {
	private int length;
	private int width;
	private int liveCount;
	private Boolean[][] board;
	private Boolean spontFormation = false;
	
	public generation(int m, int n, Boolean spont, Boolean[][] board) {
		this.length = m;
		this.width = n;
		this.spontFormation = spont;
		this.board = board;
	}
	
	public int getLiveCount() {
		return liveCount;
	}
	
	public void setLiveCount(int count) {
		this.liveCount = count;
	}
	/**
	 * Picks a random space, and if that space is deceased, there is a 1/(length * width) change that it will suddenly come to life!
	 * @param generation the board where in which the game is played.
	 */
	public void suddenLife(Boolean square) {
		Random rand = new Random(length * width);
		int mu = length*width;
		int workChance = rand.nextInt();
		if(!square) {
			if(workChance % mu != 0) {
				square = true;
				return;
			}
			else {
				return;
			}
		}
		
	}
	
	public static int findNeighbors(boolean[][] board, int x, int y) {
		int neighborCount = 0;
		boolean lookingSquare;
		int xPositions[] = {-1, 0, 1, 1, 1, 0, -1, -1};
		int yPositions[] = {1, 1, 1, 0, -1, -1, -1, 0};
		String positionNames[] = {"UL", "UU", "UR", "CR", "LR", "LD", "LL", "CL"};
		for(int i = 0; i < xPositions.length; i++) {
			if((x + xPositions[i]) < xPositions.length && (x + xPositions[i]) >= 0){
				if((y + yPositions[i]) < yPositions.length && (y + yPositions[i]) >= 0) {
					lookingSquare = board[(x + xPositions[i])][(y + yPositions[i])];
					System.out.println("Checking position " + positionNames[i] + ": " + lookingSquare);
					if(lookingSquare) {neighborCount++;}
				}
			}
		}
		return neighborCount;
	}
	
	public Boolean consequences(boolean square, int neighborCount, boolean isLiving) {
		if(isLiving) {
			switch(neighborCount) {
				case 2:
				case 3: 
					return true;
				default:
					return false;
			}
		}
		else {
			switch(neighborCount) {
			case 2:
				return false;
			case 3:
				return true;
			default:
				return false;
			}
		}
	}
	
	public static Boolean[][] createGeneration(Boolean[][] currGeneration, int x, int y, Boolean spont){
		int neighborCount = 0, indexX = 0, indexY = 0; 
		generation bool = new generation(x, y, spont, currGeneration);
		bool.board = currGeneration;
		// W.I.P For loop to call findNeighbors()
		
		/*
		 * To be determined:
		 * Logic for consequences call, and suddenLife().
		 * Possible different createGeneration method for the Boolean[][] type.
		 */
		if(bool.spontFormation) {
			bool.suddenLife(bool.board[indexX][indexY]);
		}
		return bool.board;
	}
}
