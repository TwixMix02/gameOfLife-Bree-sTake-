package environment;

import generation.Generation;


public class Medical extends Event {

	public Medical(int eventID, Boolean isPositive, int centerX, int centerY) {
		super(eventID, isPositive, centerX, centerY);
	}

	public Medical plague(int x, int y, Generation gen) {
		Medical theGreatPlague = new Medical(5, false, x, y);
		super.impactedGeneration(gen.getBoard(), gen.getSpont(), getStatus(), getID(), x, y);
		return theGreatPlague;
	}
	
	public Medical cure(int x, int y, Generation gen) {
		Medical cure = new Medical(6, true, x, y);
		super.impactedGeneration(gen.getBoard(), gen.getSpont(), getStatus(), getID(), x, y);
		return cure;
	}

}
