package environment;
import generation.Generation;
public class Migration extends Event {

	public Migration(int eventID, Boolean isPositive, int centerX, int centerY) {
		super(eventID, isPositive, centerX, centerY);
	}
	
	public Migration asylum(int x, int y, Generation gen) {
		Migration runForAsylum = new Migration(3, false, x, y);
		super.impactedGeneration(gen.getBoard(), gen.getSpont(), getStatus(), getID(), x, y);
		return runForAsylum;
	}
	
	public Migration paradise(int x, int y, Generation gen) {
		Migration paradise = new Migration(4, true, x, y);
		super.impactedGeneration(gen.getBoard(), gen.getSpont(), getStatus(), getID(), x, y);
		return paradise;
	}
}
