package environment;

import generation.Generation;

public class Other extends Event {

	public Other(int eventID, Boolean isPositive, int centerX, int centerY) {
		super(eventID, isPositive, centerX, centerY);
	}
	
	public Other anarchy(int x, int y, Generation gen) {
		Other anarchy = new Other(7, false, x, y);
		super.impactedGeneration(gen.getBoard(), gen.getSpont(), getStatus(), getID(), x, y);
		return anarchy;
	}
	
	public Other peace(int x, int y, Generation gen) {
		Other peace = new Other(8, true, x, y);
		super.impactedGeneration(gen.getBoard(), gen.getSpont(), getStatus(), getID(), x, y);
		return peace;
	}


}
