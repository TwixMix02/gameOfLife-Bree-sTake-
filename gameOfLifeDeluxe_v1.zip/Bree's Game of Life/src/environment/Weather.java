package environment;
import java.util.Random;

import generation.Generation;
public class Weather extends Event {

	public Weather(int eventID, Boolean isPositive, int centerX, int centerY) {
		super(eventID, isPositive, centerX, centerY);
	}
	
	public Weather drought(int x, int y, Generation gen) {
		Weather drought = new Weather(1, false, x, y );
		super.impactedGeneration(gen.getBoard(), gen.getSpont(), getStatus(), 1, x, y);
		return drought;
	}
	
	public Weather rains(int x, int y, Generation gen) {
		Weather rains = new Weather(2, true, x, y);
		super.impactedGeneration(gen.getBoard(), gen.getSpont(), getStatus(), getID(), x, y);
		return rains;
	}
	
	public static void main(String[] args) throws InterruptedException {
		Boolean[][] bool = new Boolean[7][7];
		Boolean spont = true;
		Generation gen = new Generation(spont, bool);
		Random rand = new Random();
		bool = gen.createGeneration(7,7,rand.nextInt((int)System.currentTimeMillis()));
		gen.setBoard(bool);
		Event event = new Event(2, true, 3, 3);
		Weather weather = new Weather(2, true, event.getX(), event.getY());
		weather.rains(event.getX(), event.getY(), gen);
		
		
	}
}
