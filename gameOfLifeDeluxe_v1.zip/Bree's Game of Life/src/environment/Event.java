package environment;
import generation.Generation;
import java.util.Random;
public class Event {
	
	private int ID;
	private Boolean status;
	private int x;
	private int y;
	
	public Event(int eventID, Boolean isPositive, int centerX, int centerY) {
	  this.ID = eventID;
	  this.status=isPositive;
	  this.x = centerX;
	  this.y = centerY;
	}
	
	public void setID(int ID) {
		this.ID = ID;
	}
	
	public int getID(){
		return ID;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	public Boolean getStatus() {
		return status;
	}
	
	public int generateEventID() {
		int eventID = 0;
		Random rand = new Random((int)System.currentTimeMillis());
		int slot = rand.nextInt((8 - 1 + 1) + 1); //Sets a random number between 1 and 8.
		if(slot == 6){
			eventID = rand.nextInt((8 - 1 + 1) + 1); //Seconds a second random number between 1 and 8
		}
		else {
			return 0;
		}
		return eventID;
	}
	
	public Event createEvent(int eventID, Boolean eventStatus, Generation gen) {
		Event currEvent = new Event(0, false, 0, 0);
		Random rand = new Random((int)System.currentTimeMillis());
		eventStatus = (eventID % 2 == 0) ? true:false;
		int x = rand.nextInt(gen.getBoard().length);
		int y = rand.nextInt(gen.getBoard()[0].length);
		currEvent.setStatus(eventStatus);
		currEvent.setX(x);
		currEvent.setY(y);
		switch(eventID) {
		case 1: currEvent.setID(1); break;
		case 2: currEvent.setID(2); break;
		case 3: currEvent.setID(3); break;
		case 4: currEvent.setID(4); break;
		case 5: currEvent.setID(5); break;
		case 6: currEvent.setID(6); break;
		case 7: currEvent.setID(7); break;
		case 8: currEvent.setID(8); break;
		default: return null;
		}
		return currEvent;
		
	}
	
	public void executeEvent(Event currEvent, Generation currGen) {
	
		Boolean eventStatus = (currEvent.getID() % 2 == 0) ? true:false;
		currEvent.setStatus(eventStatus);
		switch(currEvent.getID() /2) {
		case 1: 
			Weather weather = new Weather(currEvent.getID(), currEvent.getStatus(), currEvent.getX(), currEvent.getY());
			
			if(weather.getStatus()) {
				weather.drought(currEvent.getX(), currEvent.getY(), currGen);
			}
			else {
				weather.rains(currEvent.getX(), currEvent.getY(), currGen);
			}
		case 2:
			Migration migration = new Migration(currEvent.getID(), currEvent.getStatus(), currEvent.getX(), currEvent.getY());
			if(migration.getStatus()) {
				migration.asylum(currEvent.getX(), currEvent.getY(), currGen);
			}
			else {
				migration.paradise(currEvent.getX(), currEvent.getY(), currGen);
			}
		case 3:
			Medical medical = new Medical(currEvent.getID(), currEvent.getStatus(), currEvent.getX(), currEvent.getY());
			if(medical.getStatus()) {
				medical.plague(currEvent.getX(), currEvent.getY(), currGen);
			}
			else {
				medical.cure(currEvent.getX(), currEvent.getY(), currGen);
			}
		default:
			Other other = new Other(currEvent.getID(), currEvent.getStatus(), currEvent.getX(), currEvent.getY());
			
			if(other.getStatus()) {
				other.anarchy(currEvent.getX(), currEvent.getY(), currGen);
			}
			else {
				other.peace(currEvent.getX(), currEvent.getY(), currGen);
			}
		}
		
		
	}
	public Boolean[][] impactedGeneration(Boolean[][] board, Boolean spont, Boolean isPositive, int eventID, int x, int y ) {
		Generation gen = new Generation(spont, board);
		int xPositions[] = {-1, 0, 1, 1, 1, 0, -1, -1};
		int yPositions[] = {1, 1, 1, 0, -1, -1, -1, 0};
		int test = 0;
		Random rand = new Random(System.currentTimeMillis());
		for(int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				if (((x + xPositions[i]) < board.length) && ((x + xPositions[i]) >= 0)) {
					if (((y + yPositions[j]) < board[0].length) && ((y + yPositions[i]) >= 0)) {
						switch(eventID) {
						case 1:
							board[(x + xPositions[i])][(y + yPositions[j])] = false;
						case 2:
							board[(x + xPositions[i])][(y + yPositions[j])] = false;
						case 3:
							test = rand.nextInt(6);
							
							while(test == 0) {
								test = rand.nextInt(6);
							}
							
							if((i + 1) % 6 == 1) {
								board[(x + xPositions[i])][(y + yPositions[j])] = false;
							}
						case 4:
							test = rand.nextInt(6);
							
							while(test == 0) {
								test = rand.nextInt(6);
							}
							
							if((i + 1) % 6 == 1) {
								board[(x + xPositions[i])][(y + yPositions[j])] = true;
							}
						case 5:
							test = rand.nextInt(36);
							
							while(test == 0) {
								test = rand.nextInt(36);
							}
							
							if((i + 1) % 36 == 1) {
								board[(x + xPositions[i])][(y + yPositions[j])] = false;
							}
						case 6:
							test = rand.nextInt(36);
							
							while(test == 0) {
								test = rand.nextInt(36);
							}
							
							if((i + 1) % 36 == 1) {
								board[(x + xPositions[i])][(y + yPositions[j])] = true;
							}
						default:
							if(!isPositive) {
								test = rand.nextInt(512);
								
								while(test == 0) {
									test = rand.nextInt(512);
								}
								
								if((i + 1) % 512 == 1) {
									board[(x + xPositions[i])][(y + yPositions[j])] = false;
								}
							}
							else {
								test = rand.nextInt(512);
								
								while(test == 0) {
									test = rand.nextInt(512);
								}
								
								if((i + 1) % 512 == 1) {
									board[(x + xPositions[i])][(y + yPositions[j])] = true;
								}	
							}
						}
					}
				}
			}
		}
			
		

		return gen.getBoard();
	}
	
}


