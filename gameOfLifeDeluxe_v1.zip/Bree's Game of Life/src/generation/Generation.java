	package generation;
	import java.util.Random;
	import java.util.concurrent.TimeUnit;
	import environment.Event;

	import random.FlavorText;
	/**
	 * Generation, a class which represents a instance of a x * y sized 2D array of Boolean values, with a boolean for whether or not Spontaneous Formation (Spont. for short) is active.
	 * 
	 * @author Aubrey Selmon
	 */
	public class Generation {
		private Boolean[][] board;
		private Boolean spontFormation = false;
		
		/**
		 * Constructor method for the generation class. It has a two-dimensional array, who's length and width values can be called as board_length and board[0]_length, respectively.
		 * @param spont Toggles whether or not suddenLife() is triggered or not.
		 * @param board Representation of the infinite field of the game of life. It is finite, but under hypothesis can extend forever if given time.
		 */
		public Generation(Boolean spont, Boolean[][] board) {
			this.spontFormation = spont;
			this.board = board;
		}
		
		/**
		 * Retrieves the board Boolean[][] instance of a generation object.
		 * @return a copy of the board Boolean[][], initialized by the constructor.
		 */
		public Boolean[][] getBoard(){
			return board;
		}
		/**
		 * Initializes and defines the value of Generation.board as the provided Boolean[][] parameter.
		 * @param board A Boolean[][] used to represent the "Game of Life"
		 */
		public void setBoard(Boolean[][] board) {
			this.board = board;
		}
		/**
		 * Retrieves the spont Boolean instance of a generation object.
		 * @return spont, A Boolean used determine if suddenLife() will be used.
		 */
		public Boolean getSpont() {
			return spontFormation;
		}
		/**
		 * Initializes and defines the value of Generation.spont as the provided Boolean parameter.
		 * @param spont
		 */
		public void setSpont(Boolean spont) {
			this.spontFormation = spont;
		}
		
		/**
		 * Creates a generation instance (type Boolean[][]), and prints out a 2d representation of the generation using printGeneration()
		 * @param length The list of rows.
		 * @param width The list of columns.
		 * @param seed The seed value that is initialized for the math.
		 * @return
		 * @throws InterruptedException 
		 */
		public Boolean[][] createGeneration(int length, int width, int seed) throws InterruptedException {
			Boolean[][] generation = new Boolean[length][width];
			if (seed < 0) {
				seed *= -1;
			}
			Random rand = new Random(seed);
			Random modulo = new Random(seed);
			for(int i = 0; i< length; i++) {
				for(int j = 0; j < width; j++) {
					int fallVal = rand.nextInt();
					int mod = modulo.nextInt();
					if(fallVal % mod < modulo.nextInt()) {
						generation[i][j] = true;
					}
					else {
						generation[i][j] = false;
					}
				}
			}
			
			System.out.println("Generation created, sending 2D representation:");
			printGeneration(generation);
			return generation;
		}
		/**
		 * Prints a 2d representation of the generation instance
		 * @param gen, the generation itself.
		 * @throws InterruptedException 
		 */
		public void printGeneration(Boolean[][] gen) throws InterruptedException {
			for(int x = 0; x < gen.length; x++) {
				for(int y = 0; y < gen[x].length; y++) {
					char state = (gen[x][y]) ? 'A' : 'D';
					System.out.print("[" + state + "] ");
				}
				System.out.println();
				System.out.println();
				TimeUnit.SECONDS.sleep(1);
			}
			for(int i = 0; i < 20; i++) {
				System.out.print("- ");
			}
			System.out.println();
		}
		/**
		 * Creates and returns the subsequent generation after applying the rules of the game of life, using findNeighbors, consequences and if active suddenLife()
		 * @param currGeneration your current generation instance
		 * @param x the number of rows
		 * @param y the number of columns
		 * @param spont whether or not sudderLife() is ran.
		 * @return
		 */
		public static Boolean[][] advanceGeneration(Boolean[][] currGeneration, int x, int y, Boolean spont){
			int neighborCount = 0, indexX = 0, indexY = 0; 
			Generation generation = new Generation(null, null);
			Boolean[][] newGen = currGeneration;
			for(indexX = 0; indexX < x; indexX++) {
				for(indexY = 0; indexY < y; indexY++) {
					neighborCount = findNeighbors(currGeneration, indexX, indexY);
					newGen[indexX][indexY] = consequences(currGeneration[indexX][indexY], neighborCount, currGeneration[indexX][indexY]);
					if(!currGeneration[indexX][indexY] && spont) { 
						generation.suddenLife(newGen[indexX][indexY]);
					}
				}
			}
			return newGen;
		}
		/**
		 * Picks a random space, and if that space is deceased (represented as a 'D' in the printed grid), there is a 1/(length * width) change that it will suddenly come to life!
		 * @param generation the board where in which the game is played.
		 */
		public void suddenLife(Boolean square) {
			Random rand = new Random(System.currentTimeMillis());
			int mu = 7 * 7;
			int workChance = rand.nextInt();
			if(workChance % mu == 0) {
				workChance = rand.nextInt();
			}
			if(!square) {
				if(workChance % mu != 0) {
					square = true;
					return;
				}
				else {
					return;
				}
			}
			
		}
		/**
		 * Seatches and looks up the neighbors for a particular square.
		 * @param board the board that will be used
		 * @param x the list of rows
		 * @param y the list of columns
		 * @return the number of alive neighbors
		 */
		public static int findNeighbors(Boolean[][] board, int x, int y) {
			int neighborCount = 0;
			boolean lookingSquare = false;
			int xPositions[] = {-1, 0, 1, 1, 1, 0, -1, -1};
			int yPositions[] = {1, 1, 1, 0, -1, -1, -1, 0};
			//String positionNames[] = {"UL", "UU", "UR", "CR", "LR", "LD", "LL", "CL"};
			for(int i = 0; i < xPositions.length; i++) {
				if((x + xPositions[i]) < board.length && (x + xPositions[i]) >= 0){
					if((y + yPositions[i]) < board[0].length && (y + yPositions[i]) >= 0) {
						lookingSquare = board[(x + xPositions[i])][(y + yPositions[i])];
						//System.out.println("Checking position " + positionNames[i] + ": " + lookingSquare);
						if(lookingSquare) {neighborCount++;}
					}
				}
			}
			return neighborCount;
		}
		/**
		 * Checks to see whatever the neighbor account of the square is, and gives it a consesquence accordingly.
		 * @param square the target square.
		 * @param neighborCount the number of alive neighbors it has
		 * @param isLiving whether or not said square was alive to begin with.
		 * @return
		 */
		public static Boolean consequences(boolean square, int neighborCount, boolean isLiving) {
			if(isLiving) {
				switch(neighborCount) {
					case 2:
					case 3: 
						return true;
					default:
						return false;
				}
			}
			else {
				switch(neighborCount) {
				case 2:
					return false;
				case 3:
					return true;
				default:
					return false;
				}
			}
		}
		/**
		 * Runs the entire set of commands, and repeats with a loading delay.
		 * @param board The main field where the game is played.
		 * @param numOfRuns The number of times the method is executed.
		 * @param spont Whether or not suddenLife() is triggered.
		 * @throws InterruptedException here because of the loading screen mechanic.
		 */
		public void runSimulation(Boolean[][] board, int numOfRuns, Boolean spont) throws InterruptedException {
			for(int i = 0; i < numOfRuns; i++) {
				int eventID;
				Boolean eventStatus = false;
				Generation currGen = new Generation(spont, board);
				Event currEvent = new Event(0, false, 0, 0);
				TimeUnit.SECONDS.sleep(1);
				currGen.board = createGeneration(currGen.board.length, currGen.board[0].length, (int)System.currentTimeMillis());
				TimeUnit.SECONDS.sleep(1);
				currGen.board = advanceGeneration(currGen.board, currGen.board.length, currGen.board[0].length, spont);
				TimeUnit.SECONDS.sleep(1);
				eventID = currEvent.generateEventID();
				if(eventID > 0 && eventID < 9) {
					currEvent = currEvent.createEvent(eventID, eventStatus, currGen);
				}
				currEvent.executeEvent(currEvent, currGen);
				
				currGen.printGeneration(currGen.board);
				
				FlavorText fp = new FlavorText(eventID, (int)(System.currentTimeMillis()));
				String flavorTaste = fp.randomFlavorText(fp.getId());
				System.out.println();
				System.out.println(flavorTaste);
				System.out.println();
				TimeUnit.SECONDS.sleep(10);
			}
		}
		
		public static void main(String[] args) throws InterruptedException {
			int length = 7, width = 7;
			Boolean[][] board = new Boolean[length][width];
			Boolean spont = true;
			Generation gen = new Generation(spont, board );
			gen.setBoard(board);
			System.out.println("Welcome to the Game of Life Deluxe! Watch as the wonders of the world come to pass!");
			TimeUnit.SECONDS.sleep(5);
			System.out.println("Game of Live DELUXE V1 || Made by Aubrey Selmon for RowdyHacks IX - 2024!");
			TimeUnit.SECONDS.sleep(3);
			System.out.println("Now ready or not:");
			TimeUnit.SECONDS.sleep(4);
			System.out.println("Three");
			TimeUnit.SECONDS.sleep(1);
			System.out.println("Two");
			TimeUnit.SECONDS.sleep(1);
			System.out.println("One");
			TimeUnit.SECONDS.sleep(1);
			System.out.println("Go!");
			TimeUnit.SECONDS.sleep(1);
			gen.runSimulation(gen.board, 3, gen.spontFormation);
		}
	}


