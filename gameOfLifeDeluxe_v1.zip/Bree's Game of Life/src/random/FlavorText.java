package random;
import java.util.Random;
public class FlavorText {
	private int ID;
	private int seed;
	public FlavorText(int eventID, int randSeed) {
		this.ID = eventID;
		this.seed = randSeed;
	}
	
	public int getId() {
		return ID;
	}
	
	public int getSeed() {
		return seed;
	}
	
	public void setID(int ID) {
		this.ID = ID;
	}
	
	public void setSeed(int seed) {
		this.seed = seed;
	}
	
	public String randomFlavorText(int textID) {
		String text = " ";
		String[] flavorlessText = {"Another day in the white and grey fields", "Nothing happening here, just nature at its course", "Ever heard of Johnny Who? He was sure HOOT with the owls!", "Another generation, another way to see death and life.", "Parting is such sweet sorrow when A's turn to D's"};
		String[] droughtText = {"Hmm... yes, it is dry here.", "Where did all of the water go?", "Can't really tell the difference, it seems. White is white.", "You got a bad roll today! One in every five-hundred-twelve you get this, and this is only one-fifth of that time! If you're lucky!", "No water, so sad."};
		String[] rainsText = {"Wet.", "I swear I saw a yellow bear riding with a boy in an umbrella.", "Hopefully this isn't the workines of the Wish Giver(1983).", "Lots of A's there, good job!", "Fun fact, there is no day that doesn't have an A in it!"};
		String[] asylumText = {"This is what happens when your goverment is corrupt.", "Hope they find a better home, they didn't like your world.", "Wow, that's a lot of empty spaces. Sure hope you have the spont on!", "Wonder who's gonna take them? Not Youerica.", "They're all fleeing, tragic."};
		String[] paradiseText = {"What did you do here? Seriously!?", "Good job at doing this, though that's gonna be an awful thing to see collapse next generation.", "Paradise. Falls.", "This isn't South America, but it's close!", "Paradise is a computer nerd staying up in 3AM typing these messages."};
		String[] plagueText = {"Don't forget your masks this time.", "Well... at least you won't have any worry about big pharma!", "Okay, who let the rat bats out again?", "Surprised it only hit that small of an area.", "It's not the black death, be happy about that."};
		String[] cureText = {"Freedom, sweet sweet freedom.", "Well that's certainly something good to see, lots of healthy... selfish people... whoopee!", "So this is what it feels like to be god.", "Lots of people, lots of A's!", "What plague?"};
		String[] anarchyText = {"There's no window that hasn't been broken in this place.", "Ever hear of the Purge?", "This is what the professionals call, you've doggone messed up man!", "Chaos, chaos! Jevil, I am not.", "You're reading on FlavorText.java, what did you expect?"} ;
		String[] peaceText = {"Sounds like an Annie Lennox song.", "It's strange, knowing that all it takes is one new generation and it messes  hings up!", "Can't wait!", "All A's, baby!", "Want to test the odds?"};
		String[] secretText = {"What are you doing here? You shouldn't be reading these!", "Oops, guess there's someeee easter eggs here. Oh well, better make them super rare.", "Snocc.", "I am code, destroyer of dreams.", "There's a lot of these, but do you really care?", "Go try Minecraft! Or Terraria! Or any non-zero player game, really!", "Polymorphin Power Ranger-Ism.", "The 29th of Feburary is the perfect day to make promises three times out of every four.", "JSchlatt and Jambo are cool", "Rowdy Hacks! Rowdy Hacks!", "Ara ara.", "You really shouldn't be reading this right now.", "Are you winning, player?", "Fowateen Fowaty Fowa.", "Infinity Mode Coming... Coming... Comin... Comi.... Com... Co... C... ..."};
		Random rand = new Random(System.currentTimeMillis());
		
		switch(textID) {
			case 1:
				text = droughtText[rand.nextInt(5)];
				break;
			case 2:
				text = rainsText[rand.nextInt(5)];
				break;
			case 3:
				text = asylumText[rand.nextInt(5)];
				break;
			case 4:
				text = paradiseText[rand.nextInt(5)];
				break;
			case 5:
				text = plagueText[rand.nextInt(5)];
				break;
			case 6:
				text = cureText[rand.nextInt(5)];
				break;
			case 7:
				text = anarchyText[rand.nextInt(5)];
				break;
			case 8:
				text = peaceText[rand.nextInt(5)];
			case 9:
				Random ran = new Random(System.currentTimeMillis());
				if(ran.nextInt(1024) == 532) {
					Random ra = new Random(System.currentTimeMillis());
					text = secretText[ra.nextInt(15)];
					break;
				}
			default:
				text = flavorlessText[rand.nextInt(5)];
		}
		return text;
	}
}
